package Creationale.Singleton;

public class Main {

	public static void main(String[] args) {
		Cinematograf c1 = Cinematograf.getInstanta("Light Cinema", "Bucuresti", 2);
		Cinematograf c2 = Cinematograf.getInstanta("Light Cinema 1", "Bucuresti", 3);
		
		System.out.println(c1.toString());
		System.out.println(c2.toString()); 

	}

}
