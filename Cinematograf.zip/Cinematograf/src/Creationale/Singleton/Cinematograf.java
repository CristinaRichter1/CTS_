package Creationale.Singleton;

public class Cinematograf {
	//Singleton design pattern

	//attributes
	private String nume;
	private String adresa;
	private int nr_sali;
	private static Cinematograf instanta;
	
	//private constructor
	public Cinematograf(String nume, String adresa, int nr_sali) {
		super();
		this.nume = nume;
		this.adresa = adresa;
		this.nr_sali = nr_sali;
	}

	public static Cinematograf getInstanta(String nume, String adresa, int nr_sali) {
		if (instanta == null) {
			instanta = new Cinematograf(nume, adresa, nr_sali);
		}
		return instanta;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Cinematograf [nume= " + nume + ", adresa= " + adresa + ", nr_sali= " + nr_sali + "]";
	}
}