package Creationale.Builder;

public class Main {

	public static void main(String[] args) {
		Sala sala1 = new SalaBuilder().setNumarSala(6).setFilmDifuzat("Rocky").build();
		Sala sala2 = new SalaBuilder().setNumarSala(6).setFilmDifuzat("Rambo").build();
		System.out.println(sala1.toString());
		System.out.println(sala2.toString());
	}

}
