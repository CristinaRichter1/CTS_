package Creationale.Builder;

public interface IBuilder_Pas1 {
	public Sala build();
}
