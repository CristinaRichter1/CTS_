package Creationale.FactoryMethod;

public class FilmComedie_Pas3 implements IFilm_Pas1 {

	@Override
	public void reda(String sala) {
		System.out.println("In sala " + sala + " este o comedie");

	}

}
