package Creationale.FactoryMethod;

public class CreatorFilmActiune_Pas4 implements ICreator_Pas2 {

	@Override
	public IFilm_Pas1 createObject() {
		return new FilmActiune_Pas3();
	}

}
