package Creationale.FactoryMethod;

/*
 * Pentru apel este necesara crearea unui creator si prin intermediul acestuia se creeaza 
 * obiecte de tip film.
 */

public class Main {
	
	private static void difuzeazaFilm(ICreator_Pas2 creatorFilm, String sala) {
		IFilm_Pas1 film = creatorFilm.createObject();
		film.reda(sala);
	}

	public static void main(String[] args) {
		difuzeazaFilm(new CreatorFilmActiune_Pas4(), "Sala 1");
		difuzeazaFilm(new CreatorFilmComedie_Pas4(), "Sala 2");
		difuzeazaFilm(new CreatorFilmDrama_Pas4(), "Sala 3");
			
	}

}
