package Creationale.FactoryMethod;


/* 
 * clase creatoare de obiecte
 */
public interface ICreator_Pas2 {
	public IFilm_Pas1 createObject();
}
