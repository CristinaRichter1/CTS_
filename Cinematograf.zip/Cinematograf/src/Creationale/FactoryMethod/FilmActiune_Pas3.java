package Creationale.FactoryMethod;

public class FilmActiune_Pas3 implements IFilm_Pas1 {

	@Override
	public void reda(String sala) {
		System.out.println("In sala " + sala + " este un film de actiune");

	}

}
