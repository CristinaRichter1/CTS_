package Creationale.FactoryMethod;

public class CreatorFilmDrama_Pas4 implements ICreator_Pas2 {

	@Override
	public IFilm_Pas1 createObject() {
		return new FilmDrama_Pas3();
	}

}
