package Creationale.FactoryMethod;
/*
 * Firma LightCinema realizeaza o aplicatie pentru cinematograful pe care il gestioneaza.
 * In cadrul unei sali de cinematograf sunt difuzate mai multe categorii de filme.
 * 
 * Sa se realizeze modulul care sa permita crerea unui anumit tip de film la cerere
 * din familia filmelor existente
 * 
 * Implementarea permite adaugarea de noi categorii de filme usor, fara a se modifica codul sursa
 *  existent deja.
 */

public interface IFilm_Pas1 {
	public void reda(String sala);
}
