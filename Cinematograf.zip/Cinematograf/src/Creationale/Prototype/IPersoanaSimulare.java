package Creationale.Prototype;

public interface IPersoanaSimulare extends Cloneable{
	public IPersoanaSimulare duplica();
}
