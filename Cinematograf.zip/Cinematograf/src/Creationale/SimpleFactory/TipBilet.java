package Creationale.SimpleFactory;

/*
 * Enum-ul este folosit pentru definirea tipurilor de bilete
 * 
 * 1. enum cu tipurile de bilete
 * 2. clasa abstracta -> interfata Bilet
 * 		2.1 -> descriere()
 * 3. clase concrete -> clase pentru fiecare tip de bilet
 * 4. fabrica -> clasa pentru crearea de obiecte
 * 		4.1 -> createInstance() cu switch
 */

public enum TipBilet {
	Adult,
	Student,
	VIP
}
