package Creationale.SimpleFactory;

public interface Bilet {
	public void descriere();
}
