package Creationale.SimpleFactory;

public class BiletVIP implements Bilet{
	@Override 
	public void descriere() {
		System.out.println("Bilet pentru VIP");
	}
}
