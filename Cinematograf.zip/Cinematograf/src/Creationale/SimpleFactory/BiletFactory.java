package Creationale.SimpleFactory;

/*
 * Clasa pentru crearea de obiecte
 */

public class BiletFactory {
	Bilet createInstane(TipBilet tip) {
		//switch-ul asigura returnarea tipului cerut de apelator
		switch(tip) {
		case Adult:{
			return new BiletAdult();
		}
		case Student:{
			return new BiletStudent();
		}
		case VIP:{
			return new BiletVIP();
		} default:
			return null;
		}
	}
}
