package Creationale.SimpleFactory;

public class BiletAdult implements Bilet{

	@Override
	public void descriere() {
		System.out.println("Bilet pentru adulti");
	}

}
