package Creationale.SimpleFactory;

public class BiletStudent implements Bilet{

	@Override
	public void descriere() {
		System.out.println("Bilet pentru studenti");
	}

}
