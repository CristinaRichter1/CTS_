package Creationale.SimpleFactory;
/*
 * In cadrul cinematogrfului vor fi achizitionate mai multe tipuri de bilete.
 * Pentru adulti, studenti sau VIP.
 * Sa se implementeze modulul care genereaza un anumit tip de bilet.
 * Toate obiectele vor fi create din nfamilia Bilet.
 */

public class Main {

	public static void main(String[] args) {
		/*
		 * pentru apel se creeaa un obiect de tip BiletFactory si prin intermediul acestuia
		 * se contruiesc obiecte din familia Bilet
		 */

		BiletFactory fabrica = new BiletFactory();
		Bilet bilet;
		
		bilet = fabrica.createInstane(TipBilet.Student);
		bilet.descriere();
		bilet = fabrica.createInstane(TipBilet.VIP);
		bilet.descriere();
		bilet = fabrica.createInstane(TipBilet.Adult);
		bilet.descriere();
	}

}
