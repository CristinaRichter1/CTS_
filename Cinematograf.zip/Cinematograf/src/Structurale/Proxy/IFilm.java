package Structurale.Proxy;

public interface IFilm {
	public void ruleazaFilm();
}
