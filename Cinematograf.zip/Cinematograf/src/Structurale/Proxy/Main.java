/*
 * Cinematograful doreste ca aplicatia care ruleaza filmele in salile de spectacol
 * sa nu incarce filmul din arhiva decat in momentul in care acesta incepe sa ruleze.
 * In momentul de fata filmul este incarcat in momentul in care este anuntata sala in care va 
 * rula.
 * Managerul nu doreste sa pastreze codul existent, ci doar sa se realizeze o modificare prin
 *  care sa fie eralizat acest lucru.
 */

package Structurale.Proxy;

public class Main {

	public static void main(String[] args) {
		ProxyFilm film = new ProxyFilm("Ursul", "Sala1");
		System.out.println("Filmul nu a fost incarcat in memorie.");
		film.ruleazaFilm();
	}

}
