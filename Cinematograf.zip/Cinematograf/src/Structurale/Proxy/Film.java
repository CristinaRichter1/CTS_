package Structurale.Proxy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Film implements IFilm {
	private String denumire;
	private String sala;
	private int anApartie;
	private String regizor;
	private String[] actori;
	
	public Film(String denumire, String sala) {
		super();
		this.denumire = denumire;
		this.sala = sala;
		incarcaFilmDinArhiva(denumire);
	}
	
	public String getDenumire() {
		return denumire;
	}

	public void setDenumire(String denumire) {
		this.denumire = denumire;
	}

	public String getSala() {
		return sala;
	}

	public void setSala(String sala) {
		this.sala = sala;
	}

	private void incarcaFilmDinArhiva(String denumireFilm) {
		File file = new File(denumireFilm + ".txt"); //pathname
		FileReader fileReader = null;
		try {
			fileReader = new FileReader(file);
			@SuppressWarnings("resource")
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			anApartie = Integer.parseInt(bufferedReader.readLine());
			regizor = bufferedReader.readLine();
			int nrActori = Integer.parseInt(bufferedReader.readLine());
			actori = new String[nrActori];
			for (int i = 0; i < nrActori; i++) {
				actori[i] = bufferedReader.readLine();
			} 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			fileReader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Filmul " + denumireFilm + " este adus din arhiva in memorie.");
	}

	@Override
	public void ruleazaFilm() {
		System.out.println("Filmul " + denumire + " a inceput in sala " + sala);
		System.out.println("An aparitie film " + anApartie + " si este regizat de " + regizor);
		StringBuilder actoriStringBuilder = new StringBuilder();
		for (String actor:actori) {
			actoriStringBuilder.append(actor).append("; ");
		}
		System.out.println("Distributie: " + actoriStringBuilder);
	}

}
