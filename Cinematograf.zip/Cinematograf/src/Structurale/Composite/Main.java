/*
 * Pentru gestiunea filmelor difuzate se doresterealizarea unei arborescente cu aceste filme.
 * Arborescenta se realizeaza pe baza categoriilor din care face parte fiecare film: actiune,
 * comedie, drama.
 * Fiecare categorie poate la randul ei sa aiba subcategorii pentru filmele care sunt muzicale
 * sau filmele de actiune. Sa se implementeze un modul prin care sa fie posibila realiarea unei 
 * astfel de arborescente cu filmele difuzate in cinematograf.
 */

package Structurale.Composite;

public class Main {

	public static void main(String[] args) {
		Film f1 = new Film("Actiune");
		Film f2 = new Film("Comedie");
		Film f3 = new Film ("Muzical");
		Film f4 = new Film("Film 4");
		Film f5 = new Film("Film 5");
		
		Categorie categorie = new Categorie("Filme");
		Categorie categorie2 = new Categorie("Comedii");
		Categorie categorie3 = new Categorie("Muzical");
		Categorie categorie4 = new Categorie("Actiune");
		
		categorie.adaugaNod(categorie2);
		categorie.adaugaNod(categorie4);
		categorie.adaugaNod(categorie3);
		
		categorie4.adaugaNod(f1);
		categorie3.adaugaNod(f2);
		categorie3.adaugaNod(f5);
		categorie2.adaugaNod(f3);
		categorie2.adaugaNod(f4);
		
		categorie.printeazaDescriere("");
	}

}
