package Structurale.Decorator;

public interface IFilm {

	public void pornesteFilm();
	public void opresteFilm();
	public String getNumeFilm();
}
