package Structurale.Adapter;

public interface IFilm {
	public void pornesteFilm();
	public void opresteFilm();
}
