package Structurale.Adapter;

public class Film implements IFilm {
	private String numeFilm;

	public Film(String numeFilm) {
		super();
		this.numeFilm = numeFilm;
	}

	@Override
	public void pornesteFilm() {
		System.out.println("A inceput filmul: " + numeFilm);
	}

	@Override
	public void opresteFilm() {
		System.out.println("S-a terminat filmul: " + numeFilm);
	}

}
