package Structurale.Adapter;

public interface IPelicula {
	public void pornestePelicula();
	public void oprestePelicula();
}
