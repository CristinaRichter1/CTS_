/*
 * Utilizarea de framework-uri diferite care nu au interfata comuna.
 * Clasele existente nu se modifica, se adauga clase noi pentru realizarea unui adapter.
 * Adapterul nu adauga functionalitate,
 * functionalitatea este realizata prin clasele existente.
 */


package Structurale.Adapter;

public class Main {

	private static void ruleazaFilm(IFilm film) {
		film.pornesteFilm();
		film.opresteFilm();
	}
	
	public static void main(String[] args) {
		IFilm film = new Film("Ursul");
		IFilm pelicula = new AdapterPelicula("Apele tac");
		
		ruleazaFilm(film);
		ruleazaFilm(pelicula);
	}

}
