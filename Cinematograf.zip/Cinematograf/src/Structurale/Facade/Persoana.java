/*
 * Clasa Persoana este clasa folosita pentru crearea de persoane in cadrul clasei Public.
 */

package Structurale.Facade;

public class Persoana {
	private String nume;

	public Persoana(String nume) {
		this.nume = nume;
	}
	
	public void merge() {
		System.out.println(nume + " merge.");
	}
}
