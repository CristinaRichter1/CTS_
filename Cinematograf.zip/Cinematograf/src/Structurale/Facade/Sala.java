/*
 * Clasa Sala este ultima clasa acoperita de Facade.
 */

package Structurale.Facade;

public class Sala {
	private String numeSala;
	
	public Sala(String numeSala) {
		this.numeSala = numeSala;
	}

	public void deschideUsa() {
		System.out.println("Se deschide usa salii " + numeSala);
	}

	public void inchideUsa() {
		System.out.println("Se inchide usa salii " + numeSala);
	}
	
	public void stingeLumina() {
		System.out.println("S-a stins lumina in sala " + numeSala);
	}
	
	public void aprindeLumina() {
		System.out.println("A fost aprinsa lumina in sala " + numeSala);
	}
}
