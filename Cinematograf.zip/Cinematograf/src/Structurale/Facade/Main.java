/*
 * Managerul cinematografului doreste sa aiba implementata o functie care sa ii usureze munca
 * si sa nu mai fie nevoit sa comande deschiderea salii, aprinderea luminii, intrarea publicului
 * in sala, stingerea luminii, inchiderea usii si pornirea filmului. Doreste ca toate acestea
 * sa fie realizate printr-o singura metoda.
 * 
 * Implementati funcionalitatea dorita de manager in cadul aplicatiei cinematografului
 */

package Structurale.Facade;

public class Main {

	public static void main(String[] args) {
		Cinema_facade cinema = new Cinema_facade();
		cinema.difuzareFilmInSala("Sala1", "Film1");
	}

}
