/*
 * Clasa FabricaDeFilme contine o lista de obiecte unice IFilm dupa numele acestora.
 * Metoda getFilm() returneaza un film pe baza numelui primit ca parametru.
 * In cazul in care exista deja un film cu denumire primita in lista, se returneaza acel film.
 * In cazul in care nu exista niciun film cu acea denumire, se creeaza unul, se returneaza 
 * si se adauga in lista pentru viitoarele utilizari.
 */

package Structurale.Flyweight;

import java.util.HashMap;

public class FabricaDeFilme {
	private HashMap<String, IFilm> filme = new HashMap<String, IFilm>();
	
	public int dimensiuneListaFilme() {
		return filme.size();
	}
	
	public IFilm getFilm(String denumire) {
		IFilm film = filme.get(denumire);
		if (film == null) {
			film = new Film(denumire);
			filme.put(denumire, film);
		}
		return film;
	}
}
