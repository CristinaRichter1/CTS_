package Structurale.Flyweight;

public interface IFilm {
	public void play(Sala sala);
}
