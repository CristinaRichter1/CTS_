/*
 * In cinematograf exista mai multe sali si anumite filme sunt diuzaet in mai multe sali.
 * Managerul doreste sa organizeze difuzarea tuturor filmelor in cinemaograf insa nu doreste
 * sa pastreze in memoria aplicatiei filmele de mai multe ori. 
 * Astfel, daca un film este difuzat intr-o zi in mai mule sali in memorie filmul este retinut
 * o singura data si difuzat in fiecare sala. Sa se implementeze aceasta functionalitate in
 * cadrul aplicatiei folosita pentru gestiunea cinematografului.
 */

package Structurale.Flyweight;

public class Main {

	public static void main(String[] args) {
		FabricaDeFilme fabrica = new FabricaDeFilme();
		Sala sala1 = new Sala(1);
		Sala sala2 = new Sala(2);
		Sala sala3 = new Sala(3);
		Sala sala4 = new Sala(4);
		
		fabrica.getFilm("How to train a dragon").play(sala1);
		fabrica.getFilm("How to train a dragon").play(sala2);
		System.out.println("In lista exista: " + fabrica.dimensiuneListaFilme() + " film(e).");
		fabrica.getFilm("Ursul").play(sala3);
		fabrica.getFilm("Ursul").play(sala4);
		System.out.println("In lista exista: " + fabrica.dimensiuneListaFilme() + " film(e).");
	}
}
