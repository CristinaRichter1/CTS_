
public abstract class AnalizaMedical {
	String denumire;
	float pret;
}
