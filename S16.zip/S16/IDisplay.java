
public interface IDisplay {
	public void afisareInfo(String mesaj);
}
