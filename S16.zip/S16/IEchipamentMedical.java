
public interface IEchipamentMedical {
	
	public void incarcaEprubeta(String numePacient);
	public void procesareDate();
	public void generareRezultate();
	public void treceInStandBy();
	
}
