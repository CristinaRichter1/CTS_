

public interface ISolicitareAnaliza {
	public void analizaProba(TipAnaliza tip, String pacient);
}
