
public enum TipAnaliza {
	COVID,COLESTEROL,DEFICIT_VITAMINE
}
